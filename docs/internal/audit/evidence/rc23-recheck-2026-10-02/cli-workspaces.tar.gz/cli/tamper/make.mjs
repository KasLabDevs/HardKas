import fs from "node:fs";
import { pathToFileURL } from "node:url";
const A = await import(pathToFileURL("C:/Users/jrodr/Documents/kaslabdevs/GitHub/HardKas-repo/packages/artifacts/dist/index.js").href);
const dir = "C:/Users/jrodr/AppData/Local/Temp/claude/audit-compare/cli/tamper/";
const read = (f) => JSON.parse(fs.readFileSync(dir + f, "utf8"));
const w = (f, o) => fs.writeFileSync(dir + f, JSON.stringify(o, null, 2));
const r = read("receipt.orig.json");
// sanity: our recompute equals original
const { contentHash, ...body } = r;
console.log("recompute original matches:", A.calculateContentHash(r, 5) === r.contentHash, A.calculateContentHash(body, 5) === r.contentHash);
// (a) one byte content change (amount 150000000 -> 150000001), hash kept
w("a-byte.json", { ...r, amountSompi: "150000001" });
// (b1) status accepted->failed ; (b2) sourceSignedId changed
w("b1-status.json", { ...r, status: "failed" });
w("b2-sourceSigned.json", { ...r, sourceSignedId: "signed-deadbeefdeadbeef" });
// (c) hashVersion "x" with recomputed hash (default version) and with "x" as version
const c = { ...r, hashVersion: "x" };
let c1; try { c1 = { ...c, contentHash: A.calculateContentHash(c) }; } catch (e) { console.log("calc default threw", e.message); }
if (c1) w("c1-hashVersionX-recomputedV5.json", c1);
try { w("c2-hashVersionX-recomputedX.json", { ...c, contentHash: A.calculateContentHash(c, "x") }); } catch (e) { console.log("calc x threw:", e.constructor.name, e.message); }
// (d) bogus replay report
w("d-replay.json", { schema: "hardkas.replayReport.v1", version: "999.0.0", contentHash: "not-a-hash" });
// (e) full rewrite: amount to 999 KAS, to=carol, recompute hash v5
const e = { ...r, amountSompi: "99900000000", to: { address: "kaspa:sim_carol" }, status: "accepted" };
delete e.contentHash;
const eh = A.calculateContentHash(e, 5);
e.lineage = { ...e.lineage }; // artifactId stays old (lineage excluded?)
w("e-rewrite.json", { ...e, contentHash: eh });
console.log("e hash", eh);
