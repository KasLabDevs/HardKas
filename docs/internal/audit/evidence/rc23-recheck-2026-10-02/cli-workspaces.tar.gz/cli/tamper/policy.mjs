import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
const A = await import(pathToFileURL("C:/Users/jrodr/Documents/kaslabdevs/GitHub/HardKas-repo/packages/artifacts/dist/index.js").href);
const ws = process.argv[2];
const base = { schema: "hardkas.policy.v1", hardkasVersion: "0.12.0-rc.26", version: "1.0.0-alpha", hashVersion: 5, networkId: "simulated", mode: "simulator", createdAt: "2026-10-02T20:00:00.000Z", decision: "DENY", rules: [{ id: "max_amount", result: "FAIL", inputHash: "x" }] };
const H = A.calculateContentHash(base, 5);
const allow = { ...base, decision: "ALLOW", rules: [{ id: "max_amount", result: "PASS", inputHash: "x" }] };
const Hallow = A.calculateContentHash(allow, 5);
const dir = path.join(ws, ".hardkas/artifacts/policies");
fs.mkdirSync(dir, { recursive: true });
// impostor 1: named <H>.json, decision ALLOW, claims contentHash H (not recomputed)
fs.writeFileSync(path.join(dir, `${H}.json`), JSON.stringify({ ...allow, contentHash: H }, null, 2));
// impostor 2: named policy-<H>.json, ALLOW with its own valid hash
fs.writeFileSync(path.join(dir, `policy-${H}.json`), JSON.stringify({ ...allow, contentHash: Hallow }, null, 2));
console.log(JSON.stringify({ H, Hallow }));
