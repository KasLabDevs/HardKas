import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
const A = await import(pathToFileURL("C:/Users/jrodr/Documents/kaslabdevs/GitHub/HardKas-repo/packages/artifacts/dist/index.js").href);
const dir = "C:/Users/jrodr/AppData/Local/Temp/claude/audit-compare/cli/tamper/";
const r = JSON.parse(fs.readFileSync(dir + "receipt.orig.json", "utf8"));
// (e2) full self-consistent rewrite
const e = { ...r, amountSompi: "99900000000", to: { address: "kaspa:sim_carol" } };
delete e.contentHash;
const h = A.calculateContentHash(e, 5);
e.lineage = { ...e.lineage, artifactId: h };
const h2 = A.calculateContentHash(e, 5);
console.log("lineage.artifactId excluded from hash:", h === h2);
fs.writeFileSync(dir + "e2-rewrite-full.json", JSON.stringify({ ...e, contentHash: h2 }, null, 2));
// (f) in-workspace tamper: argv[2] = workspace receipts dir; mode byte|full
const mode = process.argv[2];
const ws = process.argv[3];
if (mode && ws) {
  const rd = path.join(ws, ".hardkas/artifacts/receipts");
  const f = fs.readdirSync(rd)[0];
  const o = JSON.parse(fs.readFileSync(path.join(rd, f), "utf8"));
  if (mode === "byte") { o.amountSompi = "150000001"; }
  else {
    o.amountSompi = "99900000000"; o.to = { address: "kaspa:sim_carol" }; delete o.contentHash;
    const hh = A.calculateContentHash(o, 5); o.lineage = { ...o.lineage, artifactId: hh }; o.contentHash = hh;
  }
  fs.writeFileSync(path.join(rd, f), JSON.stringify(o, null, 2));
  console.log("tampered", mode, f);
}
