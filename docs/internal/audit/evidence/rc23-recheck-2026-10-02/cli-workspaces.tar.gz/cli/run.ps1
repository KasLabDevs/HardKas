param([string]$Id, [string]$Cwd, [string]$Args1, [int]$Max = 60)
$cli = 'C:\Users\jrodr\Documents\kaslabdevs\GitHub\HardKas-repo\packages\cli\dist\index.js'
$log = 'C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\LOG.md'
Set-Location $Cwd
$tmpOut = [System.IO.Path]::GetTempFileName()
$p = Start-Process -FilePath node -ArgumentList (@("`"$cli`"") + $Args1) -NoNewWindow -Wait -PassThru -RedirectStandardOutput $tmpOut -RedirectStandardError "$tmpOut.err" -WorkingDirectory $Cwd
$out = [System.IO.File]::ReadAllText($tmpOut, [System.Text.Encoding]::UTF8) + [System.IO.File]::ReadAllText("$tmpOut.err", [System.Text.Encoding]::UTF8)
$ec = $p.ExitCode
$lines = $out -split "`n"
$short = ($lines | Select-Object -First $Max) -join "`n"
Add-Content -Path $log -Encoding utf8 -Value "`n### [$Id] hardkas $Args1`ncwd: $Cwd  HARDKAS_HOME: $env:HARDKAS_HOME`nexit: $ec`n``````n$short`n``````"
$moj = if ($out -match 'â|Ã') { ' MOJIBAKE!' } else { '' }
Write-Output "=== [$Id] exit=$ec$moj"
Write-Output $short
Remove-Item $tmpOut, "$tmpOut.err" -ErrorAction SilentlyContinue
