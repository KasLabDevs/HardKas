﻿# Audit re-verification LOG (HEAD 0f4c2f26b) 10/02/2026 21:54:16

### [help] hardkas --help
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```nnode:internal/modules/esm/resolve:271
    throw new ERR_MODULE_NOT_FOUND(
          ^

Error [ERR_MODULE_NOT_FOUND]: Cannot find module 'C:\Users\jrodr\Documents\kaslabdevs\GitHub\HardKas-repo\packages\localnet\node_modules\@hardkas\core\dist\index.js' imported from C:\Users\jrodr\Documents\kaslabdevs\GitHub\HardKas-repo\packages\localnet\dist\chunk-EPMJ5HSS.js
    at finalizeResolution (node:internal/modules/esm/resolve:271:11)
    at moduleResolve (node:internal/modules/esm/resolve:861:10)
    at defaultResolve (node:internal/modules/esm/resolve:988:11)
    at #cachedDefaultResolve (node:internal/modules/esm/loader:697:20)
    at #resolveAndMaybeBlockOnLoaderThread (node:internal/modules/esm/loader:714:38)
    at ModuleLoader.resolveSync (node:internal/modules/esm/loader:746:52)
    at #resolve (node:internal/modules/esm/loader:679:17)
    at ModuleLoader.getOrCreateModuleJob (node:internal/modules/esm/loader:599:35)
    at ModuleJob.syncLink (node:internal/modules/esm/module_job:162:33)
    at ModuleJob.link (node:internal/modules/esm/module_job:252:17) {
  code: 'ERR_MODULE_NOT_FOUND',
  url: 'file:///C:/Users/jrodr/Documents/kaslabdevs/GitHub/HardKas-repo/packages/localnet/node_modules/@hardkas/core/dist/index.js'
}

Node.js v24.15.0

```

### [init-help] hardkas init --help
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```nnode:internal/modules/esm/resolve:271
    throw new ERR_MODULE_NOT_FOUND(
          ^

Error [ERR_MODULE_NOT_FOUND]: Cannot find module 'C:\Users\jrodr\Documents\kaslabdevs\GitHub\HardKas-repo\packages\cli\node_modules\@hardkas\core\dist\index.js' imported from C:\Users\jrodr\Documents\kaslabdevs\GitHub\HardKas-repo\packages\cli\dist\chunk-P4NN7U65.js
    at finalizeResolution (node:internal/modules/esm/resolve:271:11)
    at moduleResolve (node:internal/modules/esm/resolve:861:10)
    at defaultResolve (node:internal/modules/esm/resolve:988:11)
    at #cachedDefaultResolve (node:internal/modules/esm/loader:697:20)
    at #resolveAndMaybeBlockOnLoaderThread (node:internal/modules/esm/loader:714:38)
    at ModuleLoader.resolveSync (node:internal/modules/esm/loader:746:52)
    at #resolve (node:internal/modules/esm/loader:679:17)
    at ModuleLoader.getOrCreateModuleJob (node:internal/modules/esm/loader:599:35)
    at ModuleJob.syncLink (node:internal/modules/esm/module_job:162:33)
    at ModuleJob.link (node:internal/modules/esm/module_job:252:17) {
  code: 'ERR_MODULE_NOT_FOUND',
  url: 'file:///C:/Users/jrodr/Documents/kaslabdevs/GitHub/HardKas-repo/packages/cli/node_modules/@hardkas/core/dist/index.js'
}

Node.js v24.15.0

```

### [help] hardkas --help
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nUsage: hardkas [options] [command]

HardKAS: Kaspa-native developer operating environment

Options:
  -V, --version                       output the version number
  -h, --help                          display help for command

Commands:
  init [options] [name]               Initialize a new HardKAS project stable
  up [options]                        Boot or validate the HardKAS developer
                                      runtime environment stable
  create [options] <template> <dest>  Scaffold a new HardKAS project from a
                                      template stable
  tx                                  L1 Transaction commands
  artifact|artifacts                  Manage HardKAS artifacts
  replay                              Manage HardKAS transaction replays
  rpc                                 Kaspa RPC diagnostics and queries
  dag                                 Simulate blockDAG operations (Localnet
                                      only)
  accounts                            Manage HardKAS accounts
  node                                Kaspa node management (Docker)
  config                              Manage HardKAS configuration
  query                               Query and introspect HardKAS artifacts,
                                      lineage, and workflows
  test [options] [files...]           Run the project's tests with Vitest and
                                      the HardKAS test helpers stable
  doctor [options] [module]           Perform a full system diagnostic and
                                      health report stable
  verify [options] [path]             Verify artifact integrity and lineage
                                      continuity across the workspace stable
  verify-semantics [options]          Verify semantic truth agreement across
                                      all HardKAS subsystems alpha
  rebuild [options]                   Wipe and rebuild the SQLite query store
                                      from the committed artifacts stable
  run [options] <script>              Run a TypeScript or JavaScript file with
                                      tsx and a global 'hardkas': a simulator
                                      test harness on simulated networks, an
                                      RPC client otherwise (not the SDK) stable
  lock                                Manage HardKAS workspace locks
  console [options]                   Open an interactive REPL with an
                                      in-memory simulator harness (h) and
                                      hash/format helpers; no network is
                                      contacted stable
  localnet                            Manage localnet state and snapshots
  simulator                           HardKAS Simulator management
  deploy                              Track and manage deployments
  dev [options]                       Local development and Igra-native
                                      environment tools
  local                               Local development and environment
                                      lifecycle tools
  kaspa                               Kaspa L1 native developer tools
  pskt                                Portable Signing Sessions (PSKT) offline
                                      coordination
  explain [options] [artifact]        Provide a narrative causal explanation of
                                      an artifact resolved by exact artifactId,
                                      artifact file path, or a namespaced
                                      identifier (--plan, --signed, --tx,
                                      --workflow) stable
  torture                             HardKAS Semantic Torture Testing Suite
  telemetry                           Inspect, verify, and monitor the
                                      canonical runtime pressure telemetry
                                      stream
  repair [options]                    Report an outdated workspace, lock files
                                      in .hardkas/, torn JSONL tails and a
                                      corrupt query store; --force repairs them
                                      beta
  rotate [options]                    Archive the telemetry stream
                                      (.hardkas/telemetry/telemetry.jsonl) once
                                      it reaches 10 MiB beta
  inspect [options]                   Inspect stream sizes and archive segments
                                      beta
  chaos [options]                     Run the internal Chaos Engine to
                                      stress-test the runtime experimental
  status [options]                    Display the current state of the local
                                      HardKAS runtime workspace
  why [options] [artifact]            Explain the causal lineage of an artifact
                                      resolved by exact artifactId, artifact
                                      file path, or a namespaced identifier
                                      (--plan, --signed, --tx, --workflow)
  ci                                  Continuous Integration and DevSecOps
                                      commands
  sandbox [options]                   Start a temporary, ephemeral HardKAS
                                      local experimentation environment
  silver                              SilverScript v1: managed silverc v1.0.0,
                                      Kaspa SDK scripts, verified canonical
                                      node
  corpus                              Verify release fixture corpora
  zk                                  Experimental local-only ZK proof artifact
                                      tools (Outputs JSON by default)
```

### [init-help] hardkas init --help
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nUsage: hardkas init [options] [name]

Initialize a new HardKAS project stable

Arguments:
  name                           Project name or directory

Options:
  --force                        Overwrite an existing hardkas.config.ts (the
                                 other scaffold files are kept) (default:
                                 false)
  --template <type>              No effect in this release (for templates use
                                 'hardkas create')
  --network <name>               'simulated' pre-creates the simulator state (5
                                 accounts, 1000 KAS each); other values skip
                                 it. The project's default target is always the
                                 simulator (default: "simulated")
  --accounts <n>                 No effect in this release: init always creates
                                 the 5 simulated accounts alice…erin
  --install                      Run npm install after scaffolding (default:
                                 false)
  --skip-toolchain               Do not install the pinned kaspa-wasm (signing,
                                 planning and the generated test need it)
                                 (default: false)
  --toolchain-from-file <asset>  Install the pinned kaspa-wasm from its
                                 official release asset already on disk
  --json                         Output results as JSON (default: false)
  -h, --help                     display help for command

```

### [1-init] hardkas init qs
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n  ℹ Created: package.json
  ℹ Created: vitest.config.ts
  ℹ Created: test/payment.test.ts
  ℹ Created: .gitignore
  ℹ Created: .hardkas/localnet.json (simulated accounts funded: 1000 KAS each)
  ℹ Installing kaspa-wasm 2.1.0, the Kaspa WASM SDK this release pins, from https://github.com/kaspanet/rusty-kaspa/releases/download/v2.1.0/kaspa-wasm32-sdk-v2.1.0.zip ...
  ℹ Installed: kaspa-wasm 2.1.0 at C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1\toolchains\kaspa-wasm\2.1.0 (SHA-256 checked against the pin)
  ✔ HardKAS project 'qs' initialized successfully.
  ℹ Project folder: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs
  ℹ Created: hardkas.config.ts (0.12.0-rc.26)

  Hint: Next steps:
  cd qs
  npm install
  npm test


```

### [1-nextsteps] cd qs; npm install
exit: 1
```nnode.exe : npm error code ETARGET
En línea: 1 Carácter: 1
+ & "D:\Program Files\nodejs/node.exe" "D:\Program Files\nodejs/node_mo ...
+ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : NotSpecified: (npm error code ETARGET:String) [], RemoteException
    + FullyQualifiedErrorId : NativeCommandError
 
npm error notarget No matching version found for @hardkas/sdk@0.12.0-rc.26.
npm error notarget In most cases you or one of your dependencies are requesting a package version that doesn't exist.
npm error A complete log of this run can be 
```

### [1-accounts] hardkas accounts list
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nHardKAS accounts

alice        kaspa:sim_alice          (synthetic)
bob          kaspa:sim_bob            (synthetic)
carol        kaspa:sim_carol          (synthetic)
dave         kaspa:sim_dave           (synthetic)
erin         kaspa:sim_erin           (synthetic)

```

### [tx-help] hardkas tx --help
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nUsage: hardkas tx [options] [command]

L1 Transaction commands

Options:
  -h, --help                          display help for command

Commands:
  profile [options] <path>            Show detailed mass and fee breakdown for
                                      a transaction plan stable
  batch [options]                     Process a batch of transactions
                                      sequentially stable
  plan [options] [from] [to]          Build a transaction plan artifact stable
  sign [options] <planPath>           Sign a transaction plan artifact stable
  status [options] <txIdOrPath>       Show the derived state of a txId
                                      (SUBMITTED, MEMPOOL_ACCEPTED, ACCEPTED,
                                      CONFIRMED, FINALIZED, REORGED, …) from
                                      the workspace evidence plus one new
                                      observation, or the signature coverage of
                                      a plan/signed artifact path
  send [options] [signedPath]         Broadcast a signed transaction or send
                                      directly stable
  receipt [options] <txId>            Show transaction receipt stable
  wait [options] <txId>               Wait until the derived state of a txId
                                      reaches ACCEPTED or CONFIRMED (blue-score
                                      depth ≥ the HardKAS policy), observing
                                      the configured node, then until that
                                      node's UTXO view reflects it stable
  verify [options] <path>             Perform deep semantic verification of a
                                      transaction plan preview
  trace <txId>                        Reconstruct the full operational trace of
                                      a transaction research
  compare <simulatedPath> <realPath>  Compare simulated vs real receipts for
                                      fidelity stable
  help [command]                      display help for command

```

### [txplan-help] hardkas tx plan --help
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nUsage: hardkas tx plan [options] [from] [to]

Build a transaction plan artifact stable

Options:
  --target <name>              Named execution target from hardkas.config.ts
  --from <accountOrAddress>    Sender account name or address (default: alice)
  --to <address>               Recipient address or account name (default: bob)
  --amount <kas>               Amount in KAS, up to 8 decimals (default: 1)
  --network <name>             simulated, simnet, devnet, testnet-10,
                               testnet-12 or mainnet (default: the config's
                               default target)
  --fee-rate <sompiPerMass>    Whole sompi per gram of mass (default: 1 in the
                               simulator, 100 on real networks; not a live
                               estimate)
  --change <accountOrAddress>  Change destination (account name or address);
                               default: the sender
  --provider <type>            Provider mode (auto, rpc, simulated) (default:
                               "auto")
  --url <url>                  Node wRPC URL (default: ws://127.0.0.1:18210 for
                               simnet and devnet; the config's rpcUrl is not
                               used)
  --out <path>                 Save plan as artifact JSON
  --save <path>                Alias for --out (Save plan as artifact JSON)
  --workflow-id <id>           Optional deterministic workflow ID override
  --assumption-level <level>   Optional assumption level override
  --wait-lock                  Wait for workspace lock if held (default: false)
  --lock-timeout <ms>          Lock wait timeout in ms (default: "30000")
  --json                       Output as JSON (default: false)
  -h, --help                   display help for command

```

### [1-plan] hardkas tx plan --from alice --to bob --amount 1.5 --out plan.json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nHardKAS Transaction Plan Artifact (v2)
======================================
Plan ID:      plan-4d476d442d9d2d3f
Version:      1.0.0-alpha
Hash:         4d476d442d9d2d3fdc8c273272105623eaf965f703ad2ee96b2dcf5877bb1d14
Created:      2026-10-02T20:03:55.604Z

Network:      simulated
Mode:         simulator

From:         kaspa:sim_alice
To:           kaspa:sim_bob
Amount:       1.5

Inputs:       1
Outputs:      1
Fee:          0.002036
Mass:         6666

Deterministic Planning Specifications:
  Coin Selection:
    deterministic canonical ordering enabled
  Input Ordering:
    amountSompi ASC
    txid ASC
    index ASC
  Output Ordering:
    amountSompi ASC
    address ASC

Artifact saved to: plan.json
Plan saved to: .hardkas\artifacts\2026-10-02T20-03-55-611Z-plan-4d476d442d9d2d3f.plan.json

```

### [1-sign] hardkas tx sign plan.json --out signed.json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nHardKAS Signed Transaction Artifact (v2)
=========================================
Signed ID:    signed-67527a8570e61705
Plan ID:      plan-4d476d442d9d2d3f
Hash:         67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693

Network:      simulated
Mode:         simulator
Status:       SIGNED

From:         kaspa:sim_alice
To:           kaspa:sim_bob
Amount:       1.5

Format:       synthetic-authorization
Tx ID:        synthetic-4d476d442d9d2d3fdc8c273272105623eaf965f703ad2ee96b2dcf5877bb1d14

Signed artifact saved to: signed.json

```

### [1-send] hardkas tx send signed.json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n
  ✔ Transaction simulated successfully

  Execution ID
    exec_mure5kq7

  Artifact ID
    ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0

  Tx ID
    synthetic-4d476d442d9d2d3fdc8c273272105623eaf965f703ad2ee96b2dcf5877bb1d14

  Network
    simulated

  Execution Scope
    local simulated execution

  Artifact Written
    C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs\.hardkas\artifacts\receipts\txReceipt-ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0.json

  Projection
    SQLite query-store (indexed while the dashboard runs)

  Replay Status
    not run (hardkas replay verify <artifactId>)

  Consensus Validated
    NO


  💡 Next Steps:
     > hardkas explain ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0
     > hardkas why ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0


```

### [1-next-explain] hardkas explain ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n
  ═════ Deterministic Explanation ═════

  This artifact represents a hardkas.txReceipt generated during a local simulated execution.


  ✔ Execution Trace

  Artifact ID
    ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0

  Tx ID
    synthetic-4d476d442d9d2d3fdc8c273272105623eaf965f703ad2ee96b2dcf5877bb1d14

  Authentication Scope
    FULL

  Resolved By
    artifactId

  Source Authority
    filesystem artifact

  File Path
    C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs\.hardkas\artifacts\receipts\txReceipt-ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0.json

  Projection Layer
    SQLite query-store (indexed while the dashboard runs)

  Integrity
    verified: the body recomputes to this artifactId (FULL scope)

  Replay
    not run by explain; run `hardkas replay verify ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0` to reproduce it

  Consensus Validation
    NOT performed

  Reason
    simulated execution mode does not validate against Kaspa consensus


```

### [1-next-why] hardkas why ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n
  ═══ Causal Lineage: ba823bbe... ═══
  ○ [37mTransaction Plan[0m
    [90mID:   4d476d442d9d2d3fdc8c273272105623eaf965f703ad2ee96b2dcf5877bb1d14[0m
    [90mInfo: Transfers to 1 outputs[0m
    [90mTime: 2026-10-02T20:03:55.604Z[0m
    └─● [37mSigned Transaction[0m
      [90mID:   67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693[0m
      [90mTxID: synthetic-4d476d442d9d2d3fdc8c273272105623eaf965f703ad2ee96b2dcf5877bb1d14[0m
      [90mTime: 2026-10-02T20:03:58.569Z[0m
      └─● [32m[1mTransaction Receipt[0m
        [90mID:   ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0[0m
        [90mTxID: synthetic-4d476d442d9d2d3fdc8c273272105623eaf965f703ad2ee96b2dcf5877bb1d14[0m
        [90mInfo: Block not observed (simulated execution)[0m
        [90mTime: 2026-10-02T20:04:01.690Z[0m


  💡 Next Steps:


```

### [1-replay-verify] hardkas replay verify ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n
  ✔ Replay Verification: ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0

  Execution Scope
    local deterministic replay

  Workspace
    ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0

  Artifacts Replayed
    3

  Lineage Integrity
    valid

  Deterministic Execution
    verified

  Network Contamination
    clean

  Status
    passed

  Result
    PASS


```

### [45-explain-bcba6f] hardkas explain bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n
  ═════ Deterministic Explanation ═════

  This artifact represents a hardkas.snapshot.v1 generated during a local simulated execution.


  ✔ Execution Trace

  Artifact ID
    bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc

  Authentication Scope
    FULL

  Resolved By
    artifactId

  Source Authority
    filesystem artifact

  File Path
    C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs\.hardkas\artifacts\misc\snapshot-bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc.json

  Projection Layer
    SQLite query-store (indexed while the dashboard runs)

  Integrity
    verified: the body recomputes to this artifactId (FULL scope)

  Replay
```

### [45-why-bcba6f] hardkas why bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n
  ═══ Causal Lineage: bcba6f17... ═══
  ○ [32m[1mUnknown[0m
    [90mID:   bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc[0m
    [90mTime: 2026-10-02T20:03:02.211Z[0m


  💡 Next Steps:


```

### [45-explain-d881f4] hardkas explain d881f4093fcb8efdb0e9a02d078990c6809ce40c8268cfabf6fd7842dec44ae2
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n
  ═════ Deterministic Explanation ═════

  This artifact represents a hardkas.snapshot.v1 generated during a local simulated execution.


  ✔ Execution Trace

  Artifact ID
    d881f4093fcb8efdb0e9a02d078990c6809ce40c8268cfabf6fd7842dec44ae2

  Authentication Scope
    FULL

  Resolved By
    artifactId

  Source Authority
    filesystem artifact

  File Path
    C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs\.hardkas\artifacts\misc\snapshot-d881f4093fcb8efdb0e9a02d078990c6809ce40c8268cfabf6fd7842dec44ae2.json

  Projection Layer
    SQLite query-store (indexed while the dashboard runs)

  Integrity
    verified: the body recomputes to this artifactId (FULL scope)

  Replay
```

### [45-why-d881f4] hardkas why d881f4093fcb8efdb0e9a02d078990c6809ce40c8268cfabf6fd7842dec44ae2
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n
  ═══ Causal Lineage: d881f409... ═══
  ○ [32m[1mUnknown[0m
    [90mID:   d881f4093fcb8efdb0e9a02d078990c6809ce40c8268cfabf6fd7842dec44ae2[0m
    [90mTime: 2026-10-02T20:04:01.696Z[0m


  💡 Next Steps:


```

### [av-help] hardkas artifact verify --help
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nUsage: hardkas artifact verify [options] <path>

Verify an artifact's integrity and schema stable

Options:
  --json              Output results as JSON (default: false)
  --recursive         Recursively verify all artifacts in a directory (default:
                      false)
  --strict            Perform deep semantic and operational safety verification
                      (default: false)
  --workspace <path>  Override workspace root directory
  -h, --help          display help for command

```

### [verify-help] hardkas verify --help
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nUsage: hardkas verify [options] [path]

Verify artifact integrity and lineage continuity across the workspace stable

Arguments:
  path        Workspace-contained artifact file or directory to verify
              (default: .hardkas/artifacts)

Options:
  --json      Output machine-readable JSON (default: false)
  -h, --help  display help for command

```

### [2-receipt.orig.json] hardkas artifact verify receipt.orig.json --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n{
  "ok": true,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": true,
    "authScope": "FULL",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "REPLAY_UNSUPPORTED_CHECK",
        "severity": "warning",
        "message": "Replay verification (full consensus simulation) is currently unsupported in this build."
      }
    ],
    "artifactType": "hardkas.txReceipt",
    "version": "1.0.0-alpha",
    "expectedHash": "ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0",
    "actualHash": "ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0"
  }
}

```

### [2-receipt.orig.json-strict] hardkas artifact verify receipt.orig.json --json --strict
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "FULL",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "Parent artifact 67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693 not found in workspace",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "PARENT_MISSING",
        "severity": "error",
        "message": "Parent artifact 67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693 not found in workspace"
      },
      {
        "code": "REPLAY_UNSUPPORTED_CHECK",
        "severity": "warning",
        "message": "Replay verification (full consensus simulation) is currently unsupported in this build."
      }
    ],
    "artifactType": "hardkas.txReceipt",
```

### [2-a-byte.json] hardkas artifact verify a-byte.json --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "FULL",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "Hash mismatch: expected ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0, got 2e47773122d54f77d0f95a42fe2779976ef50e628dc1df8fad4982592e212f39",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "ARTIFACT_HASH_MISMATCH",
        "severity": "error",
        "message": "Hash mismatch: expected ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0, got 2e47773122d54f77d0f95a42fe2779976ef50e628dc1df8fad4982592e212f39"
      },
      {
        "code": "REPLAY_UNSUPPORTED_CHECK",
        "severity": "warning",
        "message": "Replay verification (full consensus simulation) is currently unsupported in this build."
      }
    ],
    "artifactType": "hardkas.txReceipt",
```

### [2-a-byte.json-strict] hardkas artifact verify a-byte.json --json --strict
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "FULL",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "Hash mismatch: expected ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0, got 2e47773122d54f77d0f95a42fe2779976ef50e628dc1df8fad4982592e212f39",
      "Parent artifact 67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693 not found in workspace",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "ARTIFACT_HASH_MISMATCH",
        "severity": "error",
        "message": "Hash mismatch: expected ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0, got 2e47773122d54f77d0f95a42fe2779976ef50e628dc1df8fad4982592e212f39"
      },
      {
        "code": "PARENT_MISSING",
        "severity": "error",
        "message": "Parent artifact 67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693 not found in workspace"
      },
      {
```

### [2-b1-status.json] hardkas artifact verify b1-status.json --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "FULL",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "Hash mismatch: expected ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0, got 71088d47256b028d43e687ddae1f113388f16a6884d870625e54f1a46a6e4f8b",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "ARTIFACT_HASH_MISMATCH",
        "severity": "error",
        "message": "Hash mismatch: expected ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0, got 71088d47256b028d43e687ddae1f113388f16a6884d870625e54f1a46a6e4f8b"
      },
      {
        "code": "REPLAY_UNSUPPORTED_CHECK",
        "severity": "warning",
        "message": "Replay verification (full consensus simulation) is currently unsupported in this build."
      }
    ],
    "artifactType": "hardkas.txReceipt",
```

### [2-b1-status.json-strict] hardkas artifact verify b1-status.json --json --strict
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "FULL",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "Hash mismatch: expected ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0, got 71088d47256b028d43e687ddae1f113388f16a6884d870625e54f1a46a6e4f8b",
      "Parent artifact 67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693 not found in workspace",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "ARTIFACT_HASH_MISMATCH",
        "severity": "error",
        "message": "Hash mismatch: expected ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0, got 71088d47256b028d43e687ddae1f113388f16a6884d870625e54f1a46a6e4f8b"
      },
      {
        "code": "PARENT_MISSING",
        "severity": "error",
        "message": "Parent artifact 67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693 not found in workspace"
      },
      {
```

### [2-b2-sourceSigned.json] hardkas artifact verify b2-sourceSigned.json --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "FULL",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "Hash mismatch: expected ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0, got 18075e770c8d1b9db2e6245539d08b89d8c1ef8b6b997381c734ad0d85ae0e12",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "ARTIFACT_HASH_MISMATCH",
        "severity": "error",
        "message": "Hash mismatch: expected ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0, got 18075e770c8d1b9db2e6245539d08b89d8c1ef8b6b997381c734ad0d85ae0e12"
      },
      {
        "code": "REPLAY_UNSUPPORTED_CHECK",
        "severity": "warning",
        "message": "Replay verification (full consensus simulation) is currently unsupported in this build."
      }
    ],
    "artifactType": "hardkas.txReceipt",
```

### [2-b2-sourceSigned.json-strict] hardkas artifact verify b2-sourceSigned.json --json --strict
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "FULL",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "Hash mismatch: expected ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0, got 18075e770c8d1b9db2e6245539d08b89d8c1ef8b6b997381c734ad0d85ae0e12",
      "Parent artifact 67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693 not found in workspace",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "ARTIFACT_HASH_MISMATCH",
        "severity": "error",
        "message": "Hash mismatch: expected ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0, got 18075e770c8d1b9db2e6245539d08b89d8c1ef8b6b997381c734ad0d85ae0e12"
      },
      {
        "code": "PARENT_MISSING",
        "severity": "error",
        "message": "Parent artifact 67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693 not found in workspace"
      },
      {
```

### [2-c1-hashVersionX-recomputedV5.json] hardkas artifact verify c1-hashVersionX-recomputedV5.json --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "NONE",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "hashVersion must be an integer between 1 and 5 declared by the artifact; got \"x\"",
      "Lineage artifactId (ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0) does not match contentHash (9e019fd2d0c19e10caca8307aab049d6c9a84174b9405cac8e34fb4a8bb14945)",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "HASH_VERSION_INVALID",
        "severity": "error",
        "message": "hashVersion must be an integer between 1 and 5 declared by the artifact; got \"x\""
      },
      {
        "code": "LINEAGE_IDENTITY_MISMATCH",
        "severity": "error",
        "message": "Lineage artifactId (ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0) does not match contentHash (9e019fd2d0c19e10caca8307aab049d6c9a84174b9405cac8e34fb4a8bb14945)"
      },
      {
```

### [2-c1-hashVersionX-recomputedV5.json-strict] hardkas artifact verify c1-hashVersionX-recomputedV5.json --json --strict
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "NONE",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "hashVersion must be an integer between 1 and 5 declared by the artifact; got \"x\"",
      "Parent artifact 67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693 not found in workspace",
      "Lineage artifactId (ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0) does not match contentHash (9e019fd2d0c19e10caca8307aab049d6c9a84174b9405cac8e34fb4a8bb14945)",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "HASH_VERSION_INVALID",
        "severity": "error",
        "message": "hashVersion must be an integer between 1 and 5 declared by the artifact; got \"x\""
      },
      {
        "code": "PARENT_MISSING",
        "severity": "error",
        "message": "Parent artifact 67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693 not found in workspace"
      },
```

### [2-c2-hashVersionX-recomputedX.json] hardkas artifact verify c2-hashVersionX-recomputedX.json --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "NONE",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "hashVersion must be an integer between 1 and 5 declared by the artifact; got \"x\"",
      "Lineage artifactId (ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0) does not match contentHash (26ea6877bd70f6cea2aaf83ed6466fb9a7b97f52be2e64c32583cd64967c1604)",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "HASH_VERSION_INVALID",
        "severity": "error",
        "message": "hashVersion must be an integer between 1 and 5 declared by the artifact; got \"x\""
      },
      {
        "code": "LINEAGE_IDENTITY_MISMATCH",
        "severity": "error",
        "message": "Lineage artifactId (ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0) does not match contentHash (26ea6877bd70f6cea2aaf83ed6466fb9a7b97f52be2e64c32583cd64967c1604)"
      },
      {
```

### [2-c2-hashVersionX-recomputedX.json-strict] hardkas artifact verify c2-hashVersionX-recomputedX.json --json --strict
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "NONE",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "hashVersion must be an integer between 1 and 5 declared by the artifact; got \"x\"",
      "Parent artifact 67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693 not found in workspace",
      "Lineage artifactId (ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0) does not match contentHash (26ea6877bd70f6cea2aaf83ed6466fb9a7b97f52be2e64c32583cd64967c1604)",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "HASH_VERSION_INVALID",
        "severity": "error",
        "message": "hashVersion must be an integer between 1 and 5 declared by the artifact; got \"x\""
      },
      {
        "code": "PARENT_MISSING",
        "severity": "error",
        "message": "Parent artifact 67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693 not found in workspace"
      },
```

### [2-d-replay.json] hardkas artifact verify d-replay.json --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "NONE",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "Incompatible version: current system is v1, artifact is v999",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "ARTIFACT_SCHEMA_INVALID",
        "severity": "error",
        "message": "Incompatible version: current system is v1, artifact is v999"
      },
      {
        "code": "MISSING_WORKFLOW_ID",
        "severity": "warning",
        "message": "Missing workflowId"
      },
      {
        "code": "MISSING_ASSUMPTION_LEVEL",
```

### [2-d-replay.json-strict] hardkas artifact verify d-replay.json --json --strict
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "NONE",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "Incompatible version: current system is v1, artifact is v999",
      "Artifact has no lineage metadata",
      "Strict mode requires workflowId",
      "Strict mode requires assumptionLevel",
      "Strict mode requires executionMode",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "ARTIFACT_SCHEMA_INVALID",
        "severity": "error",
        "message": "Incompatible version: current system is v1, artifact is v999"
      },
      {
        "code": "MISSING_LINEAGE",
        "severity": "error",
```

### [2-e-rewrite.json] hardkas artifact verify e-rewrite.json --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "FULL",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "Lineage artifactId (ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0) does not match contentHash (821b9432c70c5228c4ea51e6c262717d95420eaffa1f3a43addf99ed75801d36)",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "LINEAGE_IDENTITY_MISMATCH",
        "severity": "error",
        "message": "Lineage artifactId (ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0) does not match contentHash (821b9432c70c5228c4ea51e6c262717d95420eaffa1f3a43addf99ed75801d36)"
      },
      {
        "code": "REPLAY_UNSUPPORTED_CHECK",
        "severity": "warning",
        "message": "Replay verification (full consensus simulation) is currently unsupported in this build."
      }
    ],
    "artifactType": "hardkas.txReceipt",
```

### [2-e-rewrite.json-strict] hardkas artifact verify e-rewrite.json --json --strict
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "FULL",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "Parent artifact 67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693 not found in workspace",
      "Lineage artifactId (ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0) does not match contentHash (821b9432c70c5228c4ea51e6c262717d95420eaffa1f3a43addf99ed75801d36)",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "PARENT_MISSING",
        "severity": "error",
        "message": "Parent artifact 67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693 not found in workspace"
      },
      {
        "code": "LINEAGE_IDENTITY_MISMATCH",
        "severity": "error",
        "message": "Lineage artifactId (ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0) does not match contentHash (821b9432c70c5228c4ea51e6c262717d95420eaffa1f3a43addf99ed75801d36)"
      },
      {
```

### [2e2] hardkas artifact verify e2-rewrite-full.json --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n{
  "ok": true,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": true,
    "authScope": "FULL",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "REPLAY_UNSUPPORTED_CHECK",
```

### [2f-verify-ws1\qs] hardkas verify
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n
  ═══ Recursive Verification: artifacts ═══
Auditing 7 artifact(s)...

  ✓ 2026-10-02T20-03-55-611Z-plan-4d476d442d9d2d3f.plan.json [MATCH]
  ✗ 2026-10-02T20-04-15.532Z-synthetic-4d476d442d9d2d3fdc8c273272105623eaf965f703ad2ee96b2dcf5877bb1d14.replay.json [FAIL]
      [!] [MISSING_LINEAGE] Artifact has no lineage metadata
      [!] [MISSING_WORKFLOW_ID] Strict mode requires workflowId
      [!] [MISSING_ASSUMPTION_LEVEL] Strict mode requires assumptionLevel
  ✓ misc\snapshot-bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc.json [MATCH]
  ✓ misc\snapshot-d881f4093fcb8efdb0e9a02d078990c6809ce40c8268cfabf6fd7842dec44ae2.json [MATCH]
  ✓ receipts\txReceipt-ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0.json [MATCH]
  ✓ signed\signedTx-67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693.json [MATCH]
  ✓ synthetic-4d476d442d9d2d3fdc8c273272105623eaf965f703ad2ee96b2dcf5877bb1d14.trace.json [MATCH]

══════════════════════════════════════════════════

  ✗ Error:
    Audit Failed: 1 artifact(s) corrupted or invalid.

  ✗ [VERIFICATION_FAILED] Recursive verification failed.

  ✗ [VERIFICATION_FAILED] Recursive verification failed.

```

### [2f-verify-ws-byte] hardkas verify
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws-byte  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n
  ═══ Recursive Verification: artifacts ═══
Auditing 7 artifact(s)...

  ✓ 2026-10-02T20-03-55-611Z-plan-4d476d442d9d2d3f.plan.json [MATCH]
  ✗ 2026-10-02T20-04-15.532Z-synthetic-4d476d442d9d2d3fdc8c273272105623eaf965f703ad2ee96b2dcf5877bb1d14.replay.json [FAIL]
      [!] [MISSING_LINEAGE] Artifact has no lineage metadata
      [!] [MISSING_WORKFLOW_ID] Strict mode requires workflowId
      [!] [MISSING_ASSUMPTION_LEVEL] Strict mode requires assumptionLevel
  ✓ misc\snapshot-bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc.json [MATCH]
  ✓ misc\snapshot-d881f4093fcb8efdb0e9a02d078990c6809ce40c8268cfabf6fd7842dec44ae2.json [MATCH]
  ✗ receipts\txReceipt-ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0.json [FAIL]
      [!] [ARTIFACT_HASH_MISMATCH] Hash mismatch: expected ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0, got 2e47773122d54f77d0f95a42fe2779976ef50e628dc1df8fad4982592e212f39
  ✓ signed\signedTx-67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693.json [MATCH]
  ✗ synthetic-4d476d442d9d2d3fdc8c273272105623eaf965f703ad2ee96b2dcf5877bb1d14.trace.json [FAIL]
      [!] [PARENT_CORRUPT] Referenced parent ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0: 1 candidate(s) for artifact "ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0" do not verify and the lookup fails closed: receipts/txReceipt-ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0.json [ARTIFACT_HASH_MISMATCH, LINEAGE_IDENTITY_MISMATCH]

══════════════════════════════════════════════════

  ✗ Error:
    Audit Failed: 3 artifact(s) corrupted or invalid.

  ✗ [VERIFICATION_FAILED] Recursive verification failed.

  ✗ [VERIFICATION_FAILED] Recursive verification failed.

```

### [2f-verify-ws-full] hardkas verify
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws-full  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n
  ═══ Recursive Verification: artifacts ═══
Auditing 7 artifact(s)...

  ✓ 2026-10-02T20-03-55-611Z-plan-4d476d442d9d2d3f.plan.json [MATCH]
  ✗ 2026-10-02T20-04-15.532Z-synthetic-4d476d442d9d2d3fdc8c273272105623eaf965f703ad2ee96b2dcf5877bb1d14.replay.json [FAIL]
      [!] [MISSING_LINEAGE] Artifact has no lineage metadata
      [!] [MISSING_WORKFLOW_ID] Strict mode requires workflowId
      [!] [MISSING_ASSUMPTION_LEVEL] Strict mode requires assumptionLevel
  ✓ misc\snapshot-bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc.json [MATCH]
  ✓ misc\snapshot-d881f4093fcb8efdb0e9a02d078990c6809ce40c8268cfabf6fd7842dec44ae2.json [MATCH]
  ✓ receipts\txReceipt-ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0.json [MATCH]
  ✓ signed\signedTx-67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693.json [MATCH]
  ✗ synthetic-4d476d442d9d2d3fdc8c273272105623eaf965f703ad2ee96b2dcf5877bb1d14.trace.json [FAIL]
      [!] [PARENT_MISSING] Parent artifact ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0 not found in workspace

══════════════════════════════════════════════════

  ✗ Error:
    Audit Failed: 2 artifact(s) corrupted or invalid.

  ✗ [VERIFICATION_FAILED] Recursive verification failed.

  ✗ [VERIFICATION_FAILED] Recursive verification failed.

```

### [2f-replay-ws-full] hardkas replay verify ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws-full  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n
  ✗ [ARTIFACT_NOT_FOUND] No verified artifact for artifact "ba823b...e5e0 [REDACTED]" in the workspace

```

### [2f-replay-ws-full-newhash] hardkas replay verify 821b9432c70c5228c4ea51e6c262717d95420eaffa1f3a43addf99ed75801d36
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws-full  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n
  ✗ Replay Verification Failed

  Cause:
    Receipt divergence at to.address: expected "kaspa:sim_carol", got "kaspa:sim_bob"

  Invariant Violated:
    deterministic execution integrity

  Consequence:
    replay artifact is corrupted and excluded from deterministic validation

  Remediation:
    restore the original artifact or regenerate the replay lineage


  Divergences found:
    receipt.to.address:
      Expected: "kaspa:sim_carol"
      Actual:   "kaspa:sim_bob"
    receipt.amountSompi:
      Expected: "99900000000"
      Actual:   "150000000"

```

### [2g-explain-H] hardkas explain 1f1c0a06f7736b5c01f7609820f3e88a345f87599bae7245fd51647acb511985
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws-policy  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n
  ✗ Artifact Not Found

  Cause:
    No verified artifact for artifact "1f1c0a06f7736b5c01f7609820f3e88a345f87599bae7245fd51647acb511985" in the workspace

  Invariant Violated:
    causal chain integrity

  Consequence:
    cannot explain deterministic causality for missing or unverifiable data

  Remediation:
    verify the artifactId or path and ensure you are in the correct HardKAS workspace


  ✗ Error:
    Command failed

```

### [2g-av-H] hardkas artifact verify 1f1c0a06f7736b5c01f7609820f3e88a345f87599bae7245fd51647acb511985 --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws-policy  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "code": "PATH_NOT_FOUND",
  "message": "Path not found: 1f1c0a06f7736b5c01f7609820f3e88a345f87599bae7245fd51647acb511985",
  "mode": "cli"
}

```

### [2g-verify] hardkas verify
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws-policy  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n
  ═══ Recursive Verification: artifacts ═══
Auditing 9 artifact(s)...

  ✓ 2026-10-02T20-03-55-611Z-plan-4d476d442d9d2d3f.plan.json [MATCH]
  ✗ 2026-10-02T20-04-15.532Z-synthetic-4d476d442d9d2d3fdc8c273272105623eaf965f703ad2ee96b2dcf5877bb1d14.replay.json [FAIL]
      [!] [MISSING_LINEAGE] Artifact has no lineage metadata
      [!] [MISSING_WORKFLOW_ID] Strict mode requires workflowId
      [!] [MISSING_ASSUMPTION_LEVEL] Strict mode requires assumptionLevel
  ✓ misc\snapshot-bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc.json [MATCH]
  ✓ misc\snapshot-d881f4093fcb8efdb0e9a02d078990c6809ce40c8268cfabf6fd7842dec44ae2.json [MATCH]
  ✗ policies\1f1c0a06f7736b5c01f7609820f3e88a345f87599bae7245fd51647acb511985.json [FAIL]
      [!] [ARTIFACT_HASH_MISMATCH] Hash mismatch: expected 1f1c0a06f7736b5c01f7609820f3e88a345f87599bae7245fd51647acb511985, got 47f58b9361ecac3ee62aa04e51c8728c0b28804eaa3fb11a136111bde6c65a6b
      [!] [MISSING_LINEAGE] Artifact has no lineage metadata
      [!] [MISSING_WORKFLOW_ID] Strict mode requires workflowId
      [!] [MISSING_ASSUMPTION_LEVEL] Strict mode requires assumptionLevel
  ✗ policies\policy-1f1c0a06f7736b5c01f7609820f3e88a345f87599bae7245fd51647acb511985.json [FAIL]
      [!] [MISSING_LINEAGE] Artifact has no lineage metadata
      [!] [MISSING_WORKFLOW_ID] Strict mode requires workflowId
      [!] [MISSING_ASSUMPTION_LEVEL] Strict mode requires assumptionLevel
  ✓ receipts\txReceipt-ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0.json [MATCH]
  ✓ signed\signedTx-67527a8570e617057a78f3ecb26ef8c9c8ed4dba4fb5acd0d8e4b51ded3ef693.json [MATCH]
  ✓ synthetic-4d476d442d9d2d3fdc8c273272105623eaf965f703ad2ee96b2dcf5877bb1d14.trace.json [MATCH]

══════════════════════════════════════════════════

  ✗ Error:
    Audit Failed: 3 artifact(s) corrupted or invalid.

  ✗ [VERIFICATION_FAILED] Recursive verification failed.
```

### [2-zod] hardkas artifact verify zod.json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n
  ✗ Error:
    Unexpected token '﻿', "﻿{
    "s"... is not valid JSON

```

### [2-zod2] hardkas artifact verify zod2.json --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "code": "UNKNOWN_ERROR",
  "message": "Unexpected token '﻿', \"﻿{\"schema\"\"... is not valid JSON",
  "mode": "cli"
}

```

### [2-zod] hardkas artifact verify zod.json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n
  ═══ Artifact Verification: zod.json ═══
  Type:    hardkas.txReceipt
  Version: 1.0.0-alpha
  Scope:   FULL
  Expected Hash: ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0
  Actual Hash:   31c5e72613fd7c8295c2926ad5ee3081f71f77f1d202cea172852c996ec8ca6b

Issues:
- ERROR:    [ARTIFACT_HASH_MISMATCH] Hash mismatch: expected ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0, got 31c5e72613fd7c8295c2926ad5ee3081f71f77f1d202cea172852c996ec8ca6b
- ERROR:    [ARTIFACT_SCHEMA_INVALID] status: [object Object]
- ERROR:    [ARTIFACT_SCHEMA_INVALID] from: [object Object]
- WARNING:  [REPLAY_UNSUPPORTED_CHECK] Replay verification (full consensus simulation) is currently unsupported in this build.

  ✗ Error:
    VERIFICATION FAILED

  ✗ [VERIFICATION_FAILED] Artifact verification failed.

```

### [2-zod2] hardkas artifact verify zod2.json --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\tamper  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "command": "artifact verify",
  "mode": "cli",
  "result": {
    "ok": false,
    "authScope": "NONE",
    "unauthenticatedMaterialFields": [],
    "errors": [
      "Missing version or schema (Artifact might be v1 or legacy)",
      "Replay verification (consensus) unsupported"
    ],
    "issues": [
      {
        "code": "ARTIFACT_SCHEMA_MISSING",
        "severity": "error",
        "message": "Missing version or schema (Artifact might be v1 or legacy)"
      },
      {
        "code": "MISSING_WORKFLOW_ID",
        "severity": "warning",
        "message": "Missing workflowId"
      },
      {
        "code": "MISSING_ASSUMPTION_LEVEL",
```

### [3-fixtures] hardkas artifact verify "C:\Users\jrodr\Documents\kaslabdevs\GitHub\HardKas-repo\packages\artifacts\test\fixtures\valid" --recursive --strict
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n
  ═══ Recursive Verification: valid ═══
Auditing 3 artifact(s)...

  ✓ signed-tx.valid.json                     [MATCH]
  ✓ snapshot.valid.json                      [MATCH]
  ✓ tx-plan.valid.json                       [MATCH]

══════════════════════════════════════════════════
  ✔ Audit Complete: All 3 artifacts verified.

```

### [4-help] hardkas accounts real generate --help
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nUsage: hardkas accounts real generate [options]

Generate new real dev account(s) using Kaspa SDK stable

Options:
  --name <name>         Base name for account(s)
  --count <number>      Number of accounts to generate (default: "1")
  --network <network>   Kaspa network (simnet, testnet-10, mainnet) (default:
                        "simnet")
  --password-stdin      Read keystore password from stdin (default: false)
  --password-env <env>  Read password from environment variable
  --unsafe-plaintext    Generate accounts in plaintext (legacy/discouraged)
                        (default: false)
  --yes                 Skip confirmation for unsafe operations (default:
                        false)
  --wait-lock           Wait for workspace lock if held (default: false)
  --lock-timeout <ms>   Lock wait timeout in ms (default: "30000")
  --json                Output as JSON (default: false)
  -h, --help            display help for command

```

### [4-a-noPw] hardkas accounts real generate --name alice_real
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n[?25h[36m?[39m [1mEnter password to encrypt 1 new account(s):[22m [2m»[22m 
```

### [4-a-pwenv] hardkas accounts real generate --name alice_real --password-env HK_TEST_PW
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nGenerated 1 real dev account(s)

WARNING: Development keys only. Do not use on mainnet.

Name:    alice_real
Address: kaspasim:qpnk98rkq7sun8cd9ka9paur92k2qks9a343s4dp5gtzaa057e9w2nles7eta
Private: yes (masked)


```

### [4-list] hardkas accounts list
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nHardKAS accounts

alice        kaspa:sim_alice          (synthetic)
bob          kaspa:sim_bob            (synthetic)
carol        kaspa:sim_carol          (synthetic)
dave         kaspa:sim_dave           (synthetic)
erin         kaspa:sim_erin           (synthetic)
alice_real   kaspasim:qpnk98rkq7sun8cd9ka9paur92k2qks9a343s4dp5gtzaa057e9w2nles7eta (kaspa) (encrypted)

```

### [4-b-plain-mainnet] hardkas accounts real generate --name m1 --unsafe-plaintext --network mainnet --yes
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nGenerated 1 real dev account(s)

WARNING: Development keys only. Do not use on mainnet.

Name:    m1
Address: kaspa:qqfzf59uy5lpngg3d4kjme2fqnal8manaydsxngyzfau29npqht9u40m7mxav
Private: yes (masked)


  ⚠️  WARNING:
     LEGACY MODE: Generating accounts in plaintext is unsafe.

```

### [4-b-plain-mainnet-noyes] hardkas accounts real generate --name m2 --unsafe-plaintext --network mainnet
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n  ⚠️  Are you sure you want to store these keys in plaintext? (y/N): 
  ⚠️  [SECURITY WARNING] Plaintext private keys detected in legacy account store for: m1
     Location: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs\.hardkas\accounts.real.json
     Recommendation: Re-import these accounts using encrypted keystores.


  ⚠️  WARNING:
     LEGACY MODE: Generating accounts in plaintext is unsafe.

```

### [4-e35-plain-noyes] hardkas accounts real generate --name p1 --unsafe-plaintext
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n  ⚠️  Are you sure you want to store these keys in plaintext? (y/N): 
  ⚠️  [SECURITY WARNING] Plaintext private keys detected in legacy account store for: m1
     Location: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs\.hardkas\accounts.real.json
     Recommendation: Re-import these accounts using encrypted keystores.


  ⚠️  WARNING:
     LEGACY MODE: Generating accounts in plaintext is unsafe.

```

### [4-c-json-enc] hardkas accounts real generate --name j1 --password-env HK_TEST_PW --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n[?25h[36m?[39m [1mEnter password to encrypt 1 new account(s):[22m [2m»[22m 
  ⚠️  [SECURITY WARNING] Plaintext private keys detected in legacy account store for: m1
     Location: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs\.hardkas\accounts.real.json
     Recommendation: Re-import these accounts using encrypted keystores.


```

### [4-c-json-plain] hardkas accounts real generate --name j2 --unsafe-plaintext --yes --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n[
  {
    "name": "j2",
    "address": "kaspasim:qpk5x2ww4c7tae5kvrhqhavvhys687av0tyuywk95l5xyvwhcyu5cm5nwm3qk",
    "network": "simnet",
    "storage": "plaintext",
    "unsafePlaintext": true,
    "store": ".hardkas/accounts.real.json",
    "publicKey": "026d4329ceae3cbee69660ee0bf58cb921a3fbac7ac9c23ac5a7e86231d7c1394c"
  }
]

  ⚠️  [SECURITY WARNING] Plaintext private keys detected in legacy account store for: m1
     Location: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs\.hardkas\accounts.real.json
     Recommendation: Re-import these accounts using encrypted keystores.


  ⚠️  WARNING:
     LEGACY MODE: Generating accounts in plaintext is unsafe.

```

### [4-c-json-enc-retry] hardkas accounts real generate --name j5 --password-env HK_TEST_PW --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n[
  {
    "name": "j5",
    "address": "kaspasim:qr5nx9t6pu3suu8smtyn68rjs4450u7r4mld3xvy748unuset9xuqjzer66ut",
    "network": "simnet",
    "storage": "encrypted-keystore",
    "unsafePlaintext": false,
    "store": ".hardkas/accounts.real.json",
    "keystore": ".hardkas/keystore/j5.json",
    "publicKey": "03e933157a0f230e70f0dac93d1c72856b47f3c3aefed89984f54fc9f219594dc0"
  }
]

  ⚠️  [SECURITY WARNING] Plaintext private keys detected in legacy account store for: m1, j2, j4
     Location: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs\.hardkas\accounts.real.json
     Recommendation: Re-import these accounts using encrypted keystores.


```

### [4-pwenv-unset] hardkas accounts real generate --name j6 --password-env HK_UNSET_VAR
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n[?25h[36m?[39m [1mEnter password to encrypt 1 new account(s):[22m [2m»[22m 
  ⚠️  [SECURITY WARNING] Plaintext private keys detected in legacy account store for: m1, j2, j4
     Location: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws1\qs\.hardkas\accounts.real.json
     Recommendation: Re-import these accounts using encrypted keystores.


```

### [5.1] hardkas tx send --out r.json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```nerror: unknown option '--out'
(Did you mean --amount?)

Usage: hardkas tx send [options] [signedPath]

Broadcast a signed transaction or send directly stable

Options:
  --target <name>            Named execution target from hardkas.config.ts
                             (signed-artifact mode: it must match the artifact
                             and never redirects the send)
  --from <accountOrAddress>  Sender (shortcut mode)
  --to <address>             Recipient (shortcut mode)
  --amount <kas>             Amount in KAS (shortcut mode)
```

### [5.2] hardkas verify receipt.json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n
  ═══ Artifact Verification: receipt.json ═══
  ✔ VERIFICATION SUCCESSFUL
  Type:    hardkas.txReceipt
  Version: 1.0.0-alpha
  Hash:    ba823bbe59a7b12780c17d16b08c554e5b42cad6bb4497beb70e7659aecde5e0
  Scope:   FULL

Operational Audit (STRICT):
  ✔   ✓ Economic & Lineage invariants verified.

Replay Verification:

  ⚠️  WARNING:
```

### [5.3] hardkas replay receipt.json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```nerror: unknown command 'receipt.json'

Usage: hardkas replay [options] [command]

Manage HardKAS transaction replays

Options:
  -h, --help                   display help for command

Commands:
  verify [options] [artifact]  Verify deterministic simulator-mode replay for a
                               receipt (required) by exact artifactId or a
                               workspace path such as ./receipt.json. Real-node
                               sends are not supported: they record a
```

### [5.4] hardkas l2 --help
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nUsage: hardkas [options] [command]

HardKAS: Kaspa-native developer operating environment

Options:
  -V, --version                       output the version number
  -h, --help                          display help for command

Commands:
  init [options] [name]               Initialize a new HardKAS project stable
  up [options]                        Boot or validate the HardKAS developer
                                      runtime environment stable
  create [options] <template> <dest>  Scaffold a new HardKAS project from a
                                      template stable
```

### [5.5] hardkas bridge --help
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nUsage: hardkas [options] [command]

HardKAS: Kaspa-native developer operating environment

Options:
  -V, --version                       output the version number
  -h, --help                          display help for command

Commands:
  init [options] [name]               Initialize a new HardKAS project stable
  up [options]                        Boot or validate the HardKAS developer
                                      runtime environment stable
  create [options] <template> <dest>  Scaffold a new HardKAS project from a
                                      template stable
```

### [5.6] hardkas networks
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```nerror: unknown command 'networks'

Usage: hardkas [options] [command]

HardKAS: Kaspa-native developer operating environment

Options:
  -V, --version                       output the version number
  -h, --help                          display help for command

Commands:
  init [options] [name]               Initialize a new HardKAS project stable
  up [options]                        Boot or validate the HardKAS developer
                                      runtime environment stable
```

### [5.7] hardkas dashboard
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```nerror: unknown command 'dashboard'

Usage: hardkas [options] [command]

HardKAS: Kaspa-native developer operating environment

Options:
  -V, --version                       output the version number
  -h, --help                          display help for command

Commands:
  init [options] [name]               Initialize a new HardKAS project stable
  up [options]                        Boot or validate the HardKAS developer
                                      runtime environment stable
```

### [5.8] hardkas query rebuild
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```nerror: unknown command 'rebuild'

Usage: hardkas query [options] [command]

Query and introspect HardKAS artifacts, lineage, and workflows

Options:
  -h, --help           display help for command

Commands:
  artifacts            Query artifact store stable
  store                Manage query store index stable
  lineage              Traverse artifact lineage stable
  replay               Inspect replay history and divergence stable
```

### [5.9] hardkas query reset
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```nerror: unknown command 'reset'

Usage: hardkas query [options] [command]

Query and introspect HardKAS artifacts, lineage, and workflows

Options:
  -h, --help           display help for command

Commands:
  artifacts            Query artifact store stable
  store                Manage query store index stable
  lineage              Traverse artifact lineage stable
  replay               Inspect replay history and divergence stable
```

### [5.10] hardkas query utxos --address x
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```nerror: unknown command 'utxos'

Usage: hardkas query [options] [command]

Query and introspect HardKAS artifacts, lineage, and workflows

Options:
  -h, --help           display help for command

Commands:
  artifacts            Query artifact store stable
  store                Manage query store index stable
  lineage              Traverse artifact lineage stable
  replay               Inspect replay history and divergence stable
```

### [5.11] hardkas accounts import
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```nerror: unknown command 'import'

Usage: hardkas accounts [options] [command]

Manage HardKAS accounts

Options:
  -h, --help                       display help for command

Commands:
  list [options]                   List available HardKAS accounts stable
  real                             Persistent dev account store (L1)
  balance [options] <identifier>   Show account balance stable
  fund [options] <identifier>      Fund an account (Faucet) - DEPRECATED
```

### [5.12] hardkas node start --profile x --help
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nUsage: hardkas node start [options]

Start local node stable

Options:
  --image <image>         Docker image
  --allow-floating-image  Allow using a floating tag like 'latest' without
                          warning (default: false)
  --wait-lock             Wait for workspace lock if held (default: false)
  --lock-timeout <ms>     Lock wait timeout in ms (default: "30000")
  --json                  Output results as JSON (default: false)
  -h, --help              display help for command

```

### [5.13] hardkas pskt combine
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```nerror: unknown command 'combine'

Usage: hardkas pskt [options] [command]

Portable Signing Sessions (PSKT) offline coordination

Options:
  -h, --help                             display help for command

Commands:
  capabilities [options]                 Show PSKT adapter capabilities alpha
  inspect [options] <sessionPath>        Inspect a PSKT session payload and metadata alpha
  verify [options] <sessionPath>         Verify integrity and lineage of a PSKT session alpha
  export [options]                       Export a TxPlan as a Portable Signing Session alpha
  import [options]                       Import a raw payload into a PSKT session alpha
  sign [options] <sessionPath>           Sign a PSKT session payload alpha
  merge [options] <sessionA> <sessionB>  Merge two PSKT sessions alpha
  finalize [options] <sessionPath>       Finalize a PSKT session alpha
  extract [options] <sessionPath>        Extract KaspaRpcTransaction from a finalized PSKT session alpha
  help [command]                         display help for command

```

### [5.14] hardkas verify --strict
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```nerror: unknown option '--strict'

Usage: hardkas verify [options] [path]

Verify artifact integrity and lineage continuity across the workspace stable

Arguments:
  path        Workspace-contained artifact file or directory to verify
              (default: .hardkas/artifacts)

Options:
  --json      Output machine-readable JSON (default: false)
  -h, --help  display help for command

```

### [5.15] hardkas repair --dry-run
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```nerror: unknown option '--dry-run'

Usage: hardkas repair [options]

Report an outdated workspace, lock files in .hardkas/, torn JSONL tails and a
corrupt query store; --force repairs them beta

Options:
  --json      Output results as stable JSON schema (default: false)
  --force     Apply the repairs (without it, repair only reports). Removes lock
              files without checking whether their process is alive (default:
              false)
  -h, --help  display help for command

```

### [5.16] hardkas query store rebuild
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n
  Rebuilding query store index...
  ✓ Index rebuilt successfully in 0ms.

  Artifacts: 0/0 indexed (0 corrupted)
  Events:    0/0 indexed (0 corrupted)


```

### [5.17] hardkas query store rebuild --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n{
  "ok": true,
  "command": "query store rebuild",
  "mode": "cli",
  "result": {
    "schema": "hardkas.queryRebuild.v1",
    "ok": true,
    "artifacts": {
      "scanned": 0,
      "indexed": 0,
      "duplicates": 0,
      "corrupted": 0
    },
    "events": {
      "scanned": 0,
      "indexed": 0,
      "duplicates": 0,
      "corrupted": 0
    },
    "warnings": [
      "Filesystem backend does not support indexing"
    ],
    "errors": []
  }
}
```

### [5.18] hardkas capabilities --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n{
  "version": "0.12.0-rc.26",
  "maturity": "hardened-alpha",
  "proofVersion": "repro-v0",
  "hashVersion": 5,
  "capabilities": {
    "artifacts": true,
    "lineageVerification": true,
    "deterministicHashing": true,
    "atomicPersistence": true,
    "workspaceLocks": true,
    "corruptionDetection": true,
    "secretRedaction": true,
    "mainnetGuards": true,
    "localnetSimulation": true,
    "ghostdagSimulation": true,
    "dagConflictResolution": true,
    "massProfiler": true,
    "simulationScenarios": true,
    "queryStore": true,
    "replayVerification": true,
    "schemaMigrations": true,
    "dockerNode": true,
    "scriptRunner": true,
    "testingFramework": true,
```

### [5.19] hardkas pskt --help
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nUsage: hardkas pskt [options] [command]

Portable Signing Sessions (PSKT) offline coordination

Options:
  -h, --help                             display help for command

Commands:
  capabilities [options]                 Show PSKT adapter capabilities alpha
  inspect [options] <sessionPath>        Inspect a PSKT session payload and metadata alpha
  verify [options] <sessionPath>         Verify integrity and lineage of a PSKT session alpha
  export [options]                       Export a TxPlan as a Portable Signing Session alpha
  import [options]                       Import a raw payload into a PSKT session alpha
  sign [options] <sessionPath>           Sign a PSKT session payload alpha
  merge [options] <sessionA> <sessionB>  Merge two PSKT sessions alpha
  finalize [options] <sessionPath>       Finalize a PSKT session alpha
  extract [options] <sessionPath>        Extract KaspaRpcTransaction from a finalized PSKT session alpha
  help [command]                         display help for command

```

### [5.20] hardkas replay verify ./receipt.json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n
  ✔ Replay Verification: receipt.json

  Execution Scope
    local deterministic replay

  Workspace
    ./receipt.json

  Artifacts Replayed
    3

  Lineage Integrity
    valid

  Deterministic Execution
    verified

  Network Contamination
    clean

  Status
    passed

  Result
```

### [5.18-full] hardkas capabilities --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n{
  "version": "0.12.0-rc.26",
  "maturity": "hardened-alpha",
  "proofVersion": "repro-v0",
  "hashVersion": 5,
  "capabilities": {
    "artifacts": true,
    "lineageVerification": true,
    "deterministicHashing": true,
    "atomicPersistence": true,
    "workspaceLocks": true,
    "corruptionDetection": true,
    "secretRedaction": true,
    "mainnetGuards": true,
    "localnetSimulation": true,
    "ghostdagSimulation": true,
    "dagConflictResolution": true,
    "massProfiler": true,
    "simulationScenarios": true,
    "queryStore": true,
    "replayVerification": true,
    "schemaMigrations": true,
    "dockerNode": true,
    "scriptRunner": true,
    "testingFramework": true,
    "l2Profiles": true,
    "l2BridgeAssumptions": true,
    "consensusValidation": false,
    "productionWallet": false,
    "silverScript": false,
    "covenants": false,
    "trustlessExit": false,
    "differentialDagValidation": false
  },
  "trustBoundaries": {
    "replay": "local-workflow-only",
    "artifacts": "internal-integrity-only",
    "simulator": "local-simulation-only",
    "queryStore": "rebuildable-read-model",
    "l2Bridge": "pre-zk-assumptions"
  }
}

⚠️  WARNING: 'capabilities' command is internal/experimental. Set HARDKAS_EXPERIMENTAL=1 to acknowledge.


```

### [5.pskt-export-help] hardkas pskt export --help
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```nUsage: hardkas pskt export [options]

Export a TxPlan as a Portable Signing Session alpha

Options:
  --plan <planPath>      Path to the TxPlan JSON artifact
  --out <sessionPath>    Path to write the new PSKT session JSON
  --adapter <adapterId>  Specific adapter ID to bind to (default:
                         kaspa-wasm-local)
  --force                Overwrite the output file if it exists (default:
                         false)
  --json                 Output results as JSON (default: false)
  -h, --help             display help for command

```

### [5.pskt-caps] hardkas pskt capabilities
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 0
```n
  ═══ PSKT Capabilities: default ═══

  Provider Version resolved-at-runtime

  Operations:
  ❌ export
  ❌ import
  ❌ inspect
  ❌ sign
  ❌ combine
  ❌ finalize
  ❌ extract

⚠️  WARNING: 'pskt' commands are highly experimental and unsupported. Set HARDKAS_EXPERIMENTAL=1 to acknowledge.


```

### [5.pskt-export] hardkas pskt export --plan plan.json --out s.json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n
⚠️  WARNING: 'pskt' commands are highly experimental and unsupported. Set HARDKAS_EXPERIMENTAL=1 to acknowledge.


  ✗ Error:
    WASM runtime does not support PSKT export

```

### [5.pskt-export-exp] hardkas pskt export --plan plan.json --out s2.json --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws5  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home1
exit: 1
```n{
  "ok": false,
  "code": "PSKT_OPERATION_UNSUPPORTED",
  "message": "WASM runtime does not support PSKT export",
  "mode": "cli"
}

```

### [R-init] hardkas init p
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home2
exit: 0
```n  ℹ Created: package.json
  ℹ Created: vitest.config.ts
  ℹ Created: test/payment.test.ts
  ℹ Created: .gitignore
  ℹ Created: .hardkas/localnet.json (simulated accounts funded: 1000 KAS each)
```

### [R-verify-0] hardkas verify
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2\p  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home2
exit: 0
```n
  ═══ Recursive Verification: artifacts ═══
Auditing 1 artifact(s)...

  ✓ misc\snapshot-bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc.json [MATCH]

══════════════════════════════════════════════════
  ✔ Audit Complete: All 1 artifacts verified.

```

### [R-send] hardkas tx send --from alice --to bob --amount 2
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2\p  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home2
exit: 3
```n
  ✗ [TX_SEND_CONFIRMATION_REQUIRED] NOT EXECUTED: 'tx send' on simulated requires explicit confirmation. Nothing was planned, signed, broadcast or written. To execute, re-run with --yes.

```

### [R-verify-1] hardkas verify
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2\p  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home2
exit: 0
```n
  ═══ Recursive Verification: artifacts ═══
Auditing 1 artifact(s)...

  ✓ misc\snapshot-bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc.json [MATCH]

══════════════════════════════════════════════════
  ✔ Audit Complete: All 1 artifacts verified.

```

### [R-replay] hardkas replay verify 
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2\p  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home2
exit: 1
```n
  ✗ [REPLAY_MISSING_DEPENDENCY] No receipt ID provided for replay verification

```

### [R-verify-2] hardkas verify --json
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2\p  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home2
exit: 0
```n{
  "ok": true,
  "command": "verify",
  "mode": "cli",
  "result": {
    "schema": "hardkas.queryVerify.v1",
    "scanned": 1,
    "successCount": 1,
    "failCount": 0,
    "results": [
      {
        "file": "misc\\snapshot-bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc.json",
        "result": {
          "ok": true,
          "authScope": "FULL",
          "unauthenticatedMaterialFields": [],
          "errors": [],
          "issues": [],
          "artifactType": "hardkas.snapshot.v1",
          "version": "1.0.0-alpha",
          "expectedHash": "bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc",
          "actualHash": "bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc"
        }
      }
    ]
  }
}

```

### [R-send-yes] hardkas tx send --from alice --to bob --amount 2 --yes
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2\p  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home2
exit: 0
```n
  ✔ Transaction simulated successfully

  Execution ID
    exec_muree7tt

  Artifact ID
    5944c2c4241754398250ffd11d3a2e8a445702558a8d02756abe73d148ee02fe

  Tx ID
    synthetic-63b251efc6064362d129646c62e23f954bb3c96b88f7f2923ad3a89668c55faf

  Network
    simulated

  Execution Scope
    local simulated execution

  Artifact Written
    C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2\p\.hardkas\artifacts\receipts\txReceipt-5944c2c4241754398250ffd11d3a2e8a445702558a8d02756abe73d148ee02fe.json

  Projection
    SQLite query-store (indexed while the dashboard runs)

  Replay Status
    not run (hardkas replay verify <artifactId>)

  Consensus Validated
    NO


  💡 Next Steps:
     > hardkas explain 5944c2c4241754398250ffd11d3a2e8a445702558a8d02756abe73d148ee02fe
     > hardkas why 5944c2c4241754398250ffd11d3a2e8a445702558a8d02756abe73d148ee02fe
     > hardkas dev last --replay
     > hardkas status


```

### [R-verify-1b] hardkas verify
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2\p  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home2
exit: 0
```n
  ═══ Recursive Verification: artifacts ═══
Auditing 6 artifact(s)...

  ✓ misc\snapshot-873abbf6985f653566db9fdcf2f6abede2fe1ab965688cb9ceefe3a94bbc7319.json [MATCH]
  ✓ misc\snapshot-bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc.json [MATCH]
  ✓ plans\txPlan-63b251efc6064362d129646c62e23f954bb3c96b88f7f2923ad3a89668c55faf.json [MATCH]
  ✓ receipts\txReceipt-5944c2c4241754398250ffd11d3a2e8a445702558a8d02756abe73d148ee02fe.json [MATCH]
  ✓ signed\signedTx-ae79c909055f582e89677c96024c15365de63b5c5d6e00cd090d7f08edb98929.json [MATCH]
  ✓ synthetic-63b251efc6064362d129646c62e23f954bb3c96b88f7f2923ad3a89668c55faf.trace.json [MATCH]

══════════════════════════════════════════════════
  ✔ Audit Complete: All 6 artifacts verified.

```

### [R-replay] hardkas replay verify 5944c2c4241754398250ffd11d3a2e8a445702558a8d02756abe73d148ee02fe
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2\p  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home2
exit: 0
```n
  ✔ Replay Verification: 5944c2c4241754398250ffd11d3a2e8a445702558a8d02756abe73d148ee02fe

  Execution Scope
    local deterministic replay
```

### [R-verify-2] hardkas verify
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2\p  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home2
exit: 1
```n
  ═══ Recursive Verification: artifacts ═══
Auditing 7 artifact(s)...

  ✗ 2026-10-02T20-10-50.895Z-synthetic-63b251efc6064362d129646c62e23f954bb3c96b88f7f2923ad3a89668c55faf.replay.json [FAIL]
      [!] [MISSING_LINEAGE] Artifact has no lineage metadata
      [!] [MISSING_WORKFLOW_ID] Strict mode requires workflowId
      [!] [MISSING_ASSUMPTION_LEVEL] Strict mode requires assumptionLevel
  ✓ misc\snapshot-873abbf6985f653566db9fdcf2f6abede2fe1ab965688cb9ceefe3a94bbc7319.json [MATCH]
  ✓ misc\snapshot-bcba6f174c6d2caac0df005dc9cfa94cd29928ede8ec9c8c63cc09e3be9c9bcc.json [MATCH]
  ✓ plans\txPlan-63b251efc6064362d129646c62e23f954bb3c96b88f7f2923ad3a89668c55faf.json [MATCH]
  ✓ receipts\txReceipt-5944c2c4241754398250ffd11d3a2e8a445702558a8d02756abe73d148ee02fe.json [MATCH]
  ✓ signed\signedTx-ae79c909055f582e89677c96024c15365de63b5c5d6e00cd090d7f08edb98929.json [MATCH]
  ✓ synthetic-63b251efc6064362d129646c62e23f954bb3c96b88f7f2923ad3a89668c55faf.trace.json [MATCH]

══════════════════════════════════════════════════

  ✗ Error:
    Audit Failed: 1 artifact(s) corrupted or invalid.

```

### [R-next-devlast] hardkas dev last --replay
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2\p  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home2
exit: 0
```n
  ✗ Error:
    No recent transaction artifacts found.

```

### [R-next-status] hardkas status
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2\p  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home2
exit: 0
```n
  ═══ HardKAS Workspace Status ═══
  ╔══════════════════════════════════════╗
  ║              Workspace               ║
  ║C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2\p║
  ╚══════════════════════════════════════╝

  Dev Server       🔴 Offline
  Kaspa Node       🔴 Offline

  Artifacts        2 indexed
  Latest Workflow  2026-10-02T20-10-50.895Z-synthetic-63b251...5faf [REDACTED].replay

  Projection       healthy

  ℹ No Dev Accounts found.

  💡 Next Steps:
     > hardkas dev --with-node
     > hardkas why --workflow 2026-10-02T20-10-50.895Z-synthetic-63b251efc6064362d129646c62e23f954bb3c96b88f7f2923ad3a89668c55faf.replay
     > hardkas dev last --replay


```

### [R-next-why-workflow] hardkas why --workflow 2026-10-02T20-10-50.895Z-synthetic-63b251efc6064362d129646c62e23f954bb3c96b88f7f2923ad3a89668c55faf.replay
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2\p  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home2
exit: 0
```n
  ✗ Error:
    Why Error: No verified workflow run with workflowId "2026-10-02T20-10-50.895Z-synthetic-63b251...5faf [REDACTED].replay" in the workspace
  Code:     ARTIFACT_NOT_FOUND

```

### [R-devlast-help] hardkas dev last --help
cwd: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\ws2\p  HARDKAS_HOME: C:\Users\jrodr\AppData\Local\Temp\claude\audit-compare\cli\home2
exit: 0
```nUsage: hardkas dev last [options]

Interact with the latest local workflow

Options:
  --inspect           Inspect the latest artifact (default: false)
  --replay            Replay the latest workflow (default: false)
  --explain           Explain the latest workflow (default: false)
  --workspace <path>  Override workspace root directory
  -h, --help          display help for command

```

## Notes
- Concurrent build was running at start (core dist missing → ERR_MODULE_NOT_FOUND); waited until CLI loaded (--version 0.12.0-rc.26).
- npm install (init next step) fails ETARGET: @hardkas/sdk@0.12.0-rc.26 not on npm (latest = rc.25). Expected for unreleased HEAD.
- HK_TEST_PW env var did not persist between PowerShell calls; first --json encrypted attempt was a harness artifact; retried OK (4-c-json-enc-retry).
- Scan of this log: mojibake â/Ã = 0; "Consensus Validated: YES"/"deterministic reproduction successful"/"Integrity: passed"/"Transfers to 0" = 0; "[object Object]" = 2; "[REDACTED]" on hashes = 3.
